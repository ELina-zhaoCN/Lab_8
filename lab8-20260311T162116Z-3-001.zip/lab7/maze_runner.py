#!/usr/bin/env python3
"""
Maze Runner - Main state machine node
States:
  EXPLORING  -> wall follower runs, wait for ArUco
  DOCKING    -> return to dock (run once)
  NAVIGATING -> undock + go to ArUco (run once)
  DONE       -> stop everything
"""
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, PoseStamped
from std_msgs.msg import Bool
from turtlebot4_navigator.robot_navigator import TurtleBot4Navigator, TaskResult
import threading

EXPLORING  = 'EXPLORING'
DOCKING    = 'DOCKING'
NAVIGATING = 'NAVIGATING'
DONE       = 'DONE'


class MazeRunner(Node):
    def __init__(self):
        super().__init__('maze_runner')

        self.state        = EXPLORING
        self.aruco_found  = False
        self.aruco_pose   = None   # PoseStamped in map frame

        # ── 防止状态重复执行的标志 ──────────────────────────────────
        self._docking_started    = False
        self._navigating_started = False

        # navigator
        self.navigator = TurtleBot4Navigator()

        # publishers
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        # subscribers
        self.create_subscription(Bool,        '/aruco_found', self.aruco_found_cb, 10)
        self.create_subscription(PoseStamped, '/aruco_pose',  self.aruco_pose_cb,  10)

        # main loop timer (轻量级状态检查，不做阻塞操作)
        self.create_timer(0.5, self.run)

        self.get_logger().info('=' * 50)
        self.get_logger().info('🏁 MAZE RUNNER STARTED — state: EXPLORING')
        self.get_logger().info('=' * 50)

    # ── callbacks ────────────────────────────────────────────────────
    def aruco_found_cb(self, msg: Bool):
        if msg.data and not self.aruco_found:
            self.aruco_found = True
            self.get_logger().info('✅ ArUco detected!')

    def aruco_pose_cb(self, msg: PoseStamped):
        if self.aruco_pose is None:
            self.aruco_pose = msg
            self.get_logger().info(
                f'📍 ArUco pose saved  x={msg.pose.position.x:.2f} '
                f'y={msg.pose.position.y:.2f}')

    # ── state machine ─────────────────────────────────────────────────
    def run(self):
        if self.state == EXPLORING:
            self.do_exploring()
        elif self.state == DOCKING and not self._docking_started:
            self._docking_started = True
            # 在后台线程执行阻塞操作，避免阻塞 ROS spin
            threading.Thread(target=self.do_docking, daemon=True).start()
        elif self.state == NAVIGATING and not self._navigating_started:
            self._navigating_started = True
            threading.Thread(target=self.do_navigating, daemon=True).start()
        elif self.state == DONE:
            self.stop()
            self.get_logger().info('🎉 DONE — mission complete!',
                                   throttle_duration_sec=5.0)

    # ── EXPLORING ─────────────────────────────────────────────────────
    def do_exploring(self):
        """wall_follower 作为独立节点运行，这里只等待 ArUco 被发现"""
        if self.aruco_found and self.aruco_pose is not None:
            self.get_logger().info('🔄 ArUco found → switching to DOCKING')
            self.stop()          # 停止 cmd_vel（wall_follower 节点也会继续，但 maze_runner 不再发命令）
            self.state = DOCKING

    # ── DOCKING ───────────────────────────────────────────────────────
    def do_docking(self):
        """在独立线程中执行，避免阻塞 spin"""
        self.get_logger().info('🏠 Returning to dock...')
        try:
            self.navigator.dock()
            result = self.navigator.getResult()
            if result == TaskResult.SUCCEEDED:
                self.get_logger().info('✅ Docked successfully → NAVIGATING')
                self.state = NAVIGATING
            else:
                self.get_logger().warn('⚠️  Dock failed, retrying...')
                self._docking_started = False   # 允许重试
        except Exception as e:
            self.get_logger().error(f'Docking exception: {e}')
            self._docking_started = False

    # ── NAVIGATING ────────────────────────────────────────────────────
    def do_navigating(self):
        """在独立线程中执行，避免阻塞 spin"""
        if self.aruco_pose is None:
            self.get_logger().warn('No ArUco pose — cannot navigate')
            self._navigating_started = False
            return

        try:
            self.get_logger().info('🚀 Undocking...')
            self.navigator.undock()

            self.get_logger().info(
                f'🚀 Navigating to ArUco at '
                f'x={self.aruco_pose.pose.position.x:.2f} '
                f'y={self.aruco_pose.pose.position.y:.2f}')

            # 在 ArUco 位置前 10cm 停下（nav2 goal offset 可通过 goal 坐标调整）
            self.navigator.goToPose(self.aruco_pose)
            result = self.navigator.getResult()

            if result == TaskResult.SUCCEEDED:
                self.get_logger().info('🎉 Reached ArUco cube!')
                self.state = DONE
            else:
                self.get_logger().warn('⚠️  Navigation failed, retrying...')
                self._navigating_started = False
        except Exception as e:
            self.get_logger().error(f'Navigation exception: {e}')
            self._navigating_started = False

    # ── helpers ───────────────────────────────────────────────────────
    def stop(self):
        self.cmd_pub.publish(Twist())


def main(args=None):
    rclpy.init(args=args)
    node = MazeRunner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()