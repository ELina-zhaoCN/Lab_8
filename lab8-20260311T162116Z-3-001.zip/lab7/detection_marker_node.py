#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CameraInfo
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Bool
from cv_bridge import CvBridge
import cv2
import numpy as np
import tf2_ros
import tf2_geometry_msgs

class ArucoDetector(Node):
    def __init__(self):
        super().__init__('aruco_detector')
        self.bridge = CvBridge()
        self.marker_size = 0.15  # meters

        self.aruco_dict   = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
        self.aruco_params = cv2.aruco.DetectorParameters()
        self.detector     = cv2.aruco.ArucoDetector(self.aruco_dict, self.aruco_params)

        self.camera_matrix = None
        self.dist_coeffs   = None
        self.saved_pose    = None

        self.tf_buffer   = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self.create_subscription(Image,      '/oakd/rgb/preview/image_raw',   self.image_callback, 10)
        self.create_subscription(CameraInfo, '/oakd/rgb/preview/camera_info', self.camera_info_cb, 10)

        self.marker_pub = self.create_publisher(Bool,        '/aruco_found', 10)
        self.pose_pub   = self.create_publisher(PoseStamped, '/aruco_pose',  10)
        self.get_logger().info("Aruco Detector Node Started")

    def camera_info_cb(self, msg: CameraInfo):
        if self.camera_matrix is None:
            self.camera_matrix = np.array(msg.k).reshape(3, 3)
            self.dist_coeffs   = np.array(msg.d)
            self.get_logger().info("Camera intrinsics received")

    def image_callback(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        corners, ids, _ = self.detector.detectMarkers(gray)

        found_msg      = Bool()
        found_msg.data = False

        if ids is not None:
            found_msg.data = True
            cv2.aruco.drawDetectedMarkers(frame, corners, ids)
            self.get_logger().info(f"Detected ArUco IDs: {ids.flatten().tolist()}")

            if self.camera_matrix is not None and self.saved_pose is None:
                for i, corner in enumerate(corners):
                    # ✅ 官方推荐的 obj_points 格式（中心为原点）
                    obj_points = np.array([
                        [-self.marker_size/2,  self.marker_size/2, 0],
                        [ self.marker_size/2,  self.marker_size/2, 0],
                        [ self.marker_size/2, -self.marker_size/2, 0],
                        [-self.marker_size/2, -self.marker_size/2, 0]
                    ], dtype=np.float32)

                    # ✅ 加 SOLVEPNP_IPPE_SQUARE 解决姿态歧义
                    success, rvec, tvec = cv2.solvePnP(
                        obj_points, corner[0],
                        self.camera_matrix, self.dist_coeffs,
                        flags=cv2.SOLVEPNP_IPPE_SQUARE)

                    if success:
                        # ✅ tvec shape 是 (3,1)，用 [0][0] 取标量
                        pose_cam = PoseStamped()
                        pose_cam.header.stamp    = msg.header.stamp
                        pose_cam.header.frame_id = 'oakd_rgb_camera_optical_frame'
                        pose_cam.pose.position.x = float(tvec[0][0])
                        pose_cam.pose.position.y = float(tvec[1][0])
                        pose_cam.pose.position.z = float(tvec[2][0])
                        pose_cam.pose.orientation.w = 1.0

                        try:
                            pose_map = self.tf_buffer.transform(
                                pose_cam, 'map',
                                timeout=rclpy.duration.Duration(seconds=1.0))
                            self.saved_pose = pose_map
                            self.get_logger().info(
                                f"✅ ArUco saved in map frame: "
                                f"x={pose_map.pose.position.x:.2f} "
                                f"y={pose_map.pose.position.y:.2f}")
                        except Exception as e:
                            # ✅ TF 失败不保存，等下一帧
                            self.get_logger().warn(f"TF failed, retrying next frame: {e}")

            if self.saved_pose is not None:
                self.saved_pose.header.stamp = self.get_clock().now().to_msg()
                self.pose_pub.publish(self.saved_pose)

        self.marker_pub.publish(found_msg)
        cv2.imshow("Aruco Detector", frame)
        cv2.waitKey(1)


def main(args=None):
    rclpy.init(args=args)
    node = ArucoDetector()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
