#!/usr/bin/env python3
import math
from typing import Optional
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
def clamp(x, lo, hi):
    return max(lo, min(hi, x))
def safe_float(x, fallback):
    try:
        return float(x)
    except Exception:
        return float(fallback)
class PIDController:
    def __init__(self, kp: float, ki: float, kd: float, setpoint: float):
        self.kp = float(kp)
        self.ki = float(ki)
        self.kd = float(kd)
        self.setpoint = float(setpoint)
        self.reset()
    def reset(self):
        self._prev_error = 0.0
        self._integral = 0.0
        self._initialized = False
    def __call__(self, measurement: float, dt: float) -> float:
        dt = max(dt, 1e-3)
        error = self.setpoint - float(measurement)
        p_out = self.kp * error
        self._integral += error * dt
        self._integral = clamp(self._integral, -1.0, 1.0)
        i_out = self.ki * self._integral
        if not self._initialized:
            d_out = 0.0
            self._initialized = True
        else:
            derivative = (error - self._prev_error) / dt
            d_out = self.kd * derivative
        self._prev_error = error
        return p_out + i_out + d_out
class WallFollower(Node):
    def __init__(self):
        super().__init__("wall_follower")
        self.declare_parameter("scan_topic", "/scan")
        self.declare_parameter("cmd_topic", "/cmd_vel")
        self.declare_parameter("target_dist", 0.40)        # CHANGED: was 1.20
        self.declare_parameter("kp", 1.8)
        self.declare_parameter("ki", 0.1)
        self.declare_parameter("kd", 0.15)
        self.declare_parameter("linear_speed", 0.15)
        self.declare_parameter("min_speed", 0.08)
        self.declare_parameter("max_ang", 2.0)
        self.declare_parameter("lookahead", 0.35)
        self.declare_parameter("front_stop_dist", 0.40)    # CHANGED: was 1.30
        self.declare_parameter("front_right_turn_dist", 0.40) # CHANGED: was 1.30
        self.declare_parameter("corner_turn_ang", 1.75)
        self.declare_parameter("window_deg", 12.0)
        self.declare_parameter("percentile", 25.0)
        self.declare_parameter("hard_min_right", 0.35)     # CHANGED: was 0.85
        self.declare_parameter("hard_turn_gain", 4.0)
        self.declare_parameter("hard_turn_max", 1.0)
        self.declare_parameter("lost_wall_dist", 0.70)     # CHANGED: was 1.5
        self.declare_parameter("reacquire_right_ang", -0.25)
        self.declare_parameter("reacquire_max", 0.5)
        self.declare_parameter("control_hz", 20.0)
        self.declare_parameter("print_debug", True)
        try:
            self.declare_parameter("use_sim_time", True)
        except Exception:
            pass
        self.scan_topic = str(self.get_parameter("scan_topic").value)
        self.cmd_topic = str(self.get_parameter("cmd_topic").value)
        self.target_dist = safe_float(self.get_parameter("target_dist").value, 0.40)
        kp = safe_float(self.get_parameter("kp").value, 1.8)
        ki = safe_float(self.get_parameter("ki").value, 0.1)
        kd = safe_float(self.get_parameter("kd").value, 0.15)
        self.linear_speed = safe_float(self.get_parameter("linear_speed").value, 0.15)
        self.min_speed = safe_float(self.get_parameter("min_speed").value, 0.08)
        self.max_ang = safe_float(self.get_parameter("max_ang").value, 2.0)
        self.lookahead = safe_float(self.get_parameter("lookahead").value, 0.35)
        self.front_stop_dist = safe_float(self.get_parameter("front_stop_dist").value, 0.40)
        self.front_right_turn_dist = safe_float(self.get_parameter("front_right_turn_dist").value, 0.40)
        self.corner_turn_ang = safe_float(self.get_parameter("corner_turn_ang").value, 1.75)
        self.window_deg = safe_float(self.get_parameter("window_deg").value, 12.0)
        self.percentile = safe_float(self.get_parameter("percentile").value, 25.0)
        self.hard_min_right = safe_float(self.get_parameter("hard_min_right").value, 0.22)
        self.hard_turn_gain = safe_float(self.get_parameter("hard_turn_gain").value, 10.0)
        self.hard_turn_max = safe_float(self.get_parameter("hard_turn_max").value, 1.8)
        self.lost_wall_dist = safe_float(self.get_parameter("lost_wall_dist").value, 0.70)
        self.reacquire_right_ang = safe_float(self.get_parameter("reacquire_right_ang").value, -0.25)
        self.reacquire_max = safe_float(self.get_parameter("reacquire_max").value, 0.5)
        self.control_hz = safe_float(self.get_parameter("control_hz").value, 20.0)
        self.print_debug = bool(self.get_parameter("print_debug").value)
        self._dbg_count = 0
        self.pid = PIDController(kp, ki, kd, self.target_dist)
        self.cmd_pub = self.create_publisher(Twist, self.cmd_topic, 10)
        self.scan_sub = self.create_subscription(
            LaserScan, self.scan_topic, self.on_scan, qos_profile_sensor_data
        )
        self.last_scan: Optional[LaserScan] = None
        self.prev_time = self.get_clock().now()
        period = 1.0 / max(self.control_hz, 1.0)
        self.timer = self.create_timer(period, self.control_loop)
        self.get_logger().info("="*60)
        self.get_logger().info(f"target_dist={self.target_dist}  front_stop={self.front_stop_dist}  hard_min={self.hard_min_right}")
        self.get_logger().info("="*60)
    def on_scan(self, msg: LaserScan):
        self.last_scan = msg
    def index_for_angle(self, scan: LaserScan, angle_rad: float) -> int:
        idx = int((angle_rad - scan.angle_min) / scan.angle_increment)
        return int(clamp(idx, 0, len(scan.ranges) - 1))
    def robust_range_at(self, scan: LaserScan, angle_rad: float,
                        window_deg: float, percentile: float) -> float:
        ranges = np.array(scan.ranges, dtype=np.float32)
        ranges[~np.isfinite(ranges)] = scan.range_max
        c = self.index_for_angle(scan, angle_rad)
        win = int(math.radians(window_deg) / max(scan.angle_increment, 1e-6))
        i0 = int(clamp(c - win, 0, len(ranges) - 1))
        i1 = int(clamp(c + win, 0, len(ranges) - 1))
        w = ranges[i0:i1 + 1]
        w = w[np.isfinite(w)]
        w = w[(w >= scan.range_min) & (w <= scan.range_max)]
        if w.size == 0:
            return float(scan.range_max)
        return float(np.percentile(w, percentile))
    def predict_right_distance(self, d_right: float, d_front_right: float) -> float:
        theta = math.pi / 4.0
        d_r = max(0.05, d_right)
        d_fr = max(0.05, d_front_right)
        alpha = math.atan2(d_fr * math.cos(theta) - d_r, d_fr * math.sin(theta))
        d_now = d_r * math.cos(alpha)
        d_future = d_now + self.lookahead * math.sin(alpha)
        return d_future
    def control_loop(self):
        if self.last_scan is None:
            return
        scan = self.last_scan
        now = self.get_clock().now()
        dt = (now - self.prev_time).nanoseconds / 1e9
        self.prev_time = now
        dt = max(dt, 1e-3)
        front_angle = 0.0
        right_angle = -math.pi / 2.0
        front_right_angle = -math.pi / 4.0
        d_front = self.robust_range_at(scan, front_angle, window_deg=10.0, percentile=20.0)
        d_right = self.robust_range_at(scan, right_angle, window_deg=self.window_deg, percentile=self.percentile)
        d_fr = self.robust_range_at(scan, front_right_angle, window_deg=10.0, percentile=20.0)
        cmd = Twist()
        if d_front < self.front_stop_dist or d_fr < self.front_right_turn_dist:
            cmd.linear.x = self.min_speed
            cmd.angular.z = self.corner_turn_ang
            self.pid.reset()
            self.cmd_pub.publish(cmd)
            if self.print_debug:
                self.get_logger().warn(f"🚧 CORNER! front={d_front:.2f}m fr={d_fr:.2f}m → turning left")
            return
        v = self.linear_speed
        d_pred = self.predict_right_distance(d_right, d_fr)
        z = self.pid(d_pred, dt)
        if d_right < self.hard_min_right:
            err = (self.hard_min_right - d_right)
            add_left = clamp(self.hard_turn_gain * err, 0.0, self.hard_turn_max)
            z += add_left
            v = self.min_speed
            if self.print_debug and self._dbg_count % 5 == 0:
                self.get_logger().warn(f"⚠️  TOO CLOSE! right={d_right:.2f}m → +{add_left:.2f} left")
        if d_right > self.lost_wall_dist:
            t = clamp((d_right - self.lost_wall_dist) / 1.0, 0.0, 1.0)
            reacq = clamp(t * self.reacquire_right_ang, -self.reacquire_max, 0.0)
            z += reacq
        z = clamp(z, -self.max_ang, self.max_ang)
        cmd.linear.x = v
        cmd.angular.z = z
        self.cmd_pub.publish(cmd)
        if self.print_debug:
            self._dbg_count += 1
            if self._dbg_count % 10 == 0:
                self.get_logger().info(
                    f"right={d_right:.2f}m | front={d_front:.2f}m | v={v:.2f} z={z:+.2f}"
                )
def main(args=None):
    rclpy.init(args=args)
    node = WallFollower()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
if __name__ == "__main__":
    main()
