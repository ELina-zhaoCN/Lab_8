import rclpy
from rclpy.node import Node
from yolo_msgs.msg import DetectionArray
from sensor_msgs.msg import Image
from visualization_msgs.msg import Marker, MarkerArray
from cv_bridge import CvBridge
import numpy as np

class DetectionMarkerNode(Node):
    def __init__(self):
        super().__init__('detection_marker_node')
        self.bridge = CvBridge()
        self.latest_depth = None

        self.sub_detections = self.create_subscription(
            DetectionArray, '/yolo/detections', self.detection_cb, 10)
        self.sub_depth = self.create_subscription(
            Image, '/oakd/rgb/preview/depth', self.depth_cb, 10)
        self.pub_markers = self.create_publisher(
            MarkerArray, '/yolo/object_markers', 10)

    def depth_cb(self, msg):
        self.latest_depth = self.bridge.imgmsg_to_cv2(
            msg, desired_encoding='passthrough')

    def detection_cb(self, msg):
        if self.latest_depth is None:
            return

        marker_array = MarkerArray()
        for i, detection in enumerate(msg.detections):
            bbox = detection.bbox
            cx = int(bbox.center.position.x)
            cy = int(bbox.center.position.y)

            h, w = self.latest_depth.shape[:2]
            cx = max(0, min(cx, w - 1))
            cy = max(0, min(cy, h - 1))

            depth = float(self.latest_depth[cy, cx])
            if depth == 0.0 or np.isnan(depth):
                continue

            marker = Marker()
            marker.header.frame_id = 'map'
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.id = i
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD
            marker.pose.position.x = depth
            marker.pose.position.y = float(cx)
            marker.pose.position.z = float(cy)
            marker.scale.x = 0.2
            marker.scale.y = 0.2
            marker.scale.z = 0.2
            marker.color.r = 1.0
            marker.color.g = 0.0
            marker.color.b = 0.0
            marker.color.a = 1.0
            marker.lifetime.sec = 1
            marker_array.markers.append(marker)

        self.pub_markers.publish(marker_array)

def main(args=None):
    rclpy.init(args=args)
    node = DetectionMarkerNode()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()