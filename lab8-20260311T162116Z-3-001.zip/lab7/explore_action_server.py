import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from std_msgs.msg import Bool
from lab7.action import Explore
import subprocess
import asyncio


class ExploreActionServer(Node):
    def __init__(self):
        super().__init__('explore_action_server')

        # 创建 Action Server
        self._action_server = ActionServer(
            self,
            Explore,
            'explore',
            self.execute_callback)

        self.marker_found = False

        # 订阅 ArUco 检测结果
        self.sub = self.create_subscription(
            Bool,
            '/aruco_found',
            self.marker_callback,
            10)

        self.get_logger().info("Explore Action Server Started")

        # wall follower 进程句柄
        self.wall_follower_proc = None

    def marker_callback(self, msg):
        if msg.data:
            self.marker_found = True
            self.get_logger().info("ArUco marker found!")

    async def execute_callback(self, goal_handle):
        self.get_logger().info("Exploration started")

        feedback = Explore.Feedback()
        result = Explore.Result()

        # 启动 wall follower 节点（假设你有 wall_follower.py）
        if self.wall_follower_proc is None:
            self.wall_follower_proc = subprocess.Popen(
                ['ros2', 'run', 'lab7', 'wall_follower_node']
            )

        self.marker_found = False

        while rclpy.ok():
            feedback.state = "Exploring..."
            goal_handle.publish_feedback(feedback)

            if self.marker_found:
                self.get_logger().info("Stopping exploration")
                result.found_marker = True
                goal_handle.succeed()

                # 停止 wall follower
                if self.wall_follower_proc is not None:
                    self.wall_follower_proc.terminate()
                    self.wall_follower_proc = None

                return result

            # asyncio sleep for non-blocking loop
            await asyncio.sleep(0.5)


def main(args=None):
    rclpy.init(args=args)
    node = ExploreActionServer()
    try:
        rclpy.spin(node)
    finally:
        rclpy.shutdown()


if __name__ == '__main__':
    main()